# MEMORY.md

## About Mitch
- Interested in security research, testing, and model capability research
- Starting to explore together - first formal session with memory

## Research Context
- Extensive research May 22, 2026 on prompt injection, model capabilities, RBAC, and framing techniques
- All materials in documents/research/
- Gemini Pro 1.5 Pro and Wally (local LLM) tested; OpenAI models not yet tested

## Gemini Capability Tests (May 24, 2026)
- Completed Gemini tests to compare with Wally baseline
- Results: Wally 59/70 (84%) vs Gemini 58/70 (83%)
- Effectively tied - very close
- Both strong on self-correction, knowledge boundaries
- Both weak on creativity

## Research Plans
- Cross-model generalization (test findings on other models)
- Structured output vulnerability (JSON/XML format effects)
- Next steps after that TBD
## Lessons Learned
*(Nothing yet)*
